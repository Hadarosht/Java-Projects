package Controller;



import java.util.Map;

import Listeners.BIListenable;
import Listeners.GUIListenable;
import Model.Athlete;
import Model.Competition;
import Model.OlympicGames;
import Model.PersonalCompetition;
import Model.TeamCompetition;
import Model.TypeOfCompetition;
import View.ActivitiesViewable;

public class Controller implements BIListenable,GUIListenable {
	//Variables
	private OlympicGames theModel;
	private ActivitiesViewable theView;
	
	
	//Constructor
	public Controller(OlympicGames m, ActivitiesViewable v) {
		theModel = m;
		theView = v;
		
		theModel.registerListener(this);
		theView.registerListener(this);
	}
	
	
	//View to Model
	@Override
	public void viewAsksForDataFromFile() {
		theModel.printDataFromFile();
	}
	@Override
	public void viewAskingToAddAthlete(String country, String name, String sportType) {
		theModel.addAthlete(country, name, sportType);
	}
	@Override
	public void viewAskingToRemoveAthlete(String id) {
		theModel.removeAthlete(id);
	}
	@Override
	public void viewAskingToAddTeam(String country, String sportType) {
		theModel.addTeam(country, sportType);
	}
	@Override
	public void viewAskingToRemoveTeam(String country, String sportType) {
		theModel.removeTeam(country, sportType);
	}
	@Override
	public void viewAskingToChangeReferee(String competitionType, String sportType, String newName, String newCountry) {
		theModel.changeReferee(competitionType, sportType, newName, newCountry);
	}
	@Override
	public void viewAskingToChangeStadium(String competitionType, String sportType, String newName, String newPlace, String newNumOfSeats) {
		theModel.changeStadium(competitionType, sportType, newName, newPlace, newNumOfSeats);
	}
	@Override
	public boolean viewCheckingParticipants() {
		return theModel.legalCompetition();
	}
	@Override
	public String viewAskingForStartDate() {
		return theModel.getStartDate();
	}
	@Override
	public int[] viewAskingForFinalData() {
		return theModel.getAmount();
	}
	@Override
	public int viewAskingForAmountOfCountry(String amountCheck) {
		return theModel.countryAppearance(amountCheck);
	}
	@Override
	public void viewAskingForTopThreeAndQuit() {
		theModel.showTopThreeAndQuit();
	}
	
	
	
	
	//Model to View
	@Override
	public void printInfoFromFile(TypeOfCompetition<?> c) {
		theView.printData(c);
	}
	@Override
	public void notificationFromEvent(String msg) {
		theView.notificationToView(msg);
	}
	@Override
	public void errorNotificationFromEvent(String msg) {
		theView.errorNotification(msg);
	}
	@Override
	public void addAthleteToModelEvent(Athlete a, PersonalCompetition c) {
		theView.addAthlete(a, c);
	}
	@Override
	public void removeAthleteFromModelEvent(Athlete a, PersonalCompetition c) {
		theView.removeAthlete(a, c);
	}
	@Override
	public void addTeamToModelEvent(String country, String sportType, TeamCompetition c) {
		theView.addTeam(country, sportType, c);
	}
	@Override
	public void removeTeamFromModelEvent(String country, String sportType, TeamCompetition c) {
		theView.removeTeam(country, sportType, c);
	}
	@Override
	public void changeRefereeFromModelEvent(String newName, String competitionType, String sportType, Competition c) {
		theView.refereeChanged(newName, competitionType, sportType, c);
	}
	@Override
	public void changeStadiumFromModelEvent(String newName, String newPlace, int numOfSeats, Competition c) {
		theView.stadiumChanged(newName, newPlace, numOfSeats, c);
	}
	@Override
	public void olympicGamesHasFinishedMessage(String winnersMsg, Map<String,Integer> countryParticipants) {
		theView.endMessage(winnersMsg, countryParticipants);
	}
}

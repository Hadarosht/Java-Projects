package Starter;

import Controller.Controller;
import Model.OlympicGames;
import View.MenuView;
import View.PCView;
import View.TCView;
import javafx.application.Application;
import javafx.stage.Stage;

public class Program extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primayStage) throws Exception {
		OlympicGames theModel = new OlympicGames();
		MenuView theMenuView = new MenuView(primayStage);
		Controller controllerMenu = new Controller(theModel, theMenuView);
		
		PCView view1 = new PCView(new Stage());
		Controller controller1 =  new Controller(theModel, view1);
		
		TCView view2 = new TCView(new Stage());
		Controller controller2 = new Controller(theModel, view2);
	}

}

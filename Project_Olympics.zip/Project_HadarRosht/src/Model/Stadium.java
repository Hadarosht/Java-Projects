package Model;

public class Stadium {
	//Variables
	private String name;
	private String place;
	private int numberOfSeats;
	
	
	//Constructor
	public Stadium(String name, String place, int numberOfSeats) {
		this.name = name;
		this.place = place;
		this.numberOfSeats = numberOfSeats;
	}
	//Reading constructor
	public Stadium() {
		this.name = null;
		this.place = null;
		this.numberOfSeats = 0;
	}


	//Getters and setters
	public String getName() {
		return name;
	}
	public void setNewName(String name) {
		this.name = name;
	}
	public int getNumberOfSeats() {
		return numberOfSeats;
	}
	public void setNewNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}
	public String getPlace() {
		return place;
	}
	public void setNewPlace(String newPlace) {
		place = newPlace;
	}


	//ToString
	@Override
	public String toString() {
		if (name == null) {
			return "No Stadium assigned yet";

		}
		else {
			return "Name: " + name + "\nPlace: " + place + "\nNumber Of Seats: " + numberOfSeats;
		}
	}


	//equals
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Stadium other = (Stadium) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (numberOfSeats != other.numberOfSeats)
			return false;
		if (place == null) {
			if (other.place != null)
				return false;
		} else if (!place.equals(other.place))
			return false;
		return true;
	}
}

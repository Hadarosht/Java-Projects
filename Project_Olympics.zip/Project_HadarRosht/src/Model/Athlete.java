package Model;

import java.util.Scanner;

public class Athlete extends Team implements Cloneable {
	//Variables
	protected static int SETIAL_ID_ATHLETE = 1;
	
	private String name;
	private int id;
	

	//Constructor reading
	public Athlete(Scanner read) throws Exception {
		super(read);
		id = SETIAL_ID_ATHLETE++;
		setName(read.nextLine());
	}
	//Constructor
	public Athlete(String country, String name) {
		super(country);
		this.name = name;
		id = SETIAL_ID_ATHLETE++;
	}


	//Getters and setters
	public int getID() {
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}


	//toString
	@Override
	public String toString() {
		return "Athlete [Id= "+ id +", Name=" + name +  ", Team="+super.toString()+"]" +"\n";
	}

	
	//Equals
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Athlete other = (Athlete) obj;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	

	//copy of the athlete
	@Override
	public Athlete clone() throws CloneNotSupportedException {
		return (Athlete) super.clone();
	}
}

package Model;

public class Referee {
	//Variables
	private String name;
	private String country;
	private String typeOfSport;
	
	
	//Constructor
	public Referee(String name, String country, String typeOfSport) {
		this.name = name;
		this.country = country;
		this.typeOfSport = typeOfSport;
	}
	//Empty constructor
	public Referee() {
		this.name = null;
		this.country = null;
		this.typeOfSport = null;
	}
	
	
	//Getters and setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTypeOfSport() {
		return typeOfSport;
	}
	public void setTypeOfSport(String typeOfSport) {
		this.typeOfSport = typeOfSport;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String newCountry) {
		country = newCountry;
	}

	
	//toString
	@Override
	public String toString() {
		if (name == null) {
			return "No referee assigned yet";
		}
		else {
			return "Name: " + name + "\nCountry: " + country + "\nType Of Sport: " + typeOfSport;
		}
	}

	
	//equals
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Referee other = (Referee) obj;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (typeOfSport == null) {
			if (other.typeOfSport != null)
				return false;
		} else if (!typeOfSport.equals(other.typeOfSport))
			return false;
		return true;
	}
}

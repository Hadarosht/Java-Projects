package Model;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class PersonalCompetition extends Competition implements CompetitionManageable {
	//Variables
	private ArrayList<Athlete> attendeesListPersonal;
	private String[] topThree;
	
	
	//Constructor
	public PersonalCompetition(String sportType) {
		super(sportType);
		attendeesListPersonal = new ArrayList<Athlete>();
		topThree = new String[3];
	}
	
	
	//Reading constructor
	public PersonalCompetition(Scanner read) throws Exception {
		super(read);
		attendeesListPersonal = new ArrayList<Athlete>();
		int amount;
		try {
			amount = read.nextInt();
		}
		catch(InputMismatchException e) {
			throw new Exception("The amount number of the athletes is worng!");
		}
		read.nextLine();
		for (int i = 0; i < amount; i++) {
			//adding new athlete to competition
			attendeesListPersonal.add(new Athlete(read));
		}
		//creating array of the top three winners
		topThree = new String[3];
	}
	
	
	//Getters and Setters
	public ArrayList<Athlete> getAttendeesList() {
		return attendeesListPersonal;
	}
	
	
	//toString
	@Override
	public String toString() {
		String text = "";
		text += super.toString();
		//checking if there is any athletes in the competition
		if (attendeesListPersonal.size() == 0) {
			text += "No Athletes assigned yet";
		}
		else {
			for (int i = 0; i < attendeesListPersonal.size(); i++) {
				text += attendeesListPersonal.get(i).toString();
			}
		}
		return text;
	}
	
	
	//Methods
	public void addAthleteToCompetition(Athlete a) {
		//adding the athlete to the competition
		attendeesListPersonal.add(a);
	}
	public Athlete removeAthleteFromCompetition(int checkId) {
		//removing the athlete from the competition
		for (int i = 0; i < attendeesListPersonal.size(); i++) {
			if (attendeesListPersonal.get(i).getID() == checkId) {
				Athlete a = attendeesListPersonal.get(i);
				//removing the athlete both from competition and the list of the countries
				attendeesListPersonal.remove(i);
				return a;
			}
		}
		return null;
	}
	//pick three random athletes from 
	public void startCompetition() {
		Random rnd = new Random();
		int selected=0;
		//picking randomly 3 athletes winners (first index is 1st place)
		for (int i = 0; i < 3; i++) {
			selected = rnd.nextInt(attendeesListPersonal.size());
			topThree[i] = attendeesListPersonal.get(selected).getCountry();
			//removing from the array the selected one
			attendeesListPersonal.remove(selected);
		
		}
	}
	@Override
	public String[] getTopThree() {
		return topThree;
	}
	@Override
	public String getTopThreeText(){
		return "The winners of personal competition in "+getSportType()+ " sport are: \n"+
				"1st - "+topThree[0]+"\n"+
				"2st - "+topThree[1]+"\n"+
				"3st - "+topThree[2];
	}
}

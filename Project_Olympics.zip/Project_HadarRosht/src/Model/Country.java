package Model;

public class Country extends Team{
	//Variables
	private int amountOfPoints;
	
	
	//Constructor
	public Country(String country, int pointsCalculated) {
		super(country);
		setAmountofPoints(pointsCalculated);
	}
	
	
	//Getters and setters
	public int getAmountOfPoints() {
		return amountOfPoints;
	}
	public void setAmountofPoints(int pointsCalculated) {
		amountOfPoints = pointsCalculated;
	}
	
	
	//Methods
	public void addPoint() {
		amountOfPoints++;
	}

	
	//toString
	@Override
	public String toString() {
		return super.toString() + " - " + amountOfPoints + "Points";
	}
}

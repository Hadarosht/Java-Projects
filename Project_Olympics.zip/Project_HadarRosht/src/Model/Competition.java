package Model;

import java.util.InputMismatchException;
import java.util.Scanner;

public abstract class Competition implements Cloneable{
	//Variables
	
	public static final String[] typeOfSport = {"Runner","Jumper","Runner&Jumper"};
	
	private String sportType;
	private Referee referee;
	private Stadium stadium;
	
	
	//Constructor
	public Competition(String sportType) {
		this.sportType = sportType;
		//starting empty referee and stadium
		referee = new Referee();
		stadium = new Stadium();
	}
	
	
	//Reading constructor
	public Competition(Scanner read) throws Exception {
		//checking the type of the sport in the file
		String sportType = read.nextLine();
		if (sportTypeCorrect(sportType)) {
			this.sportType = sportType;
			//continue to read Referee values
			String name,country,typeOfSportReferee;
			name = read.nextLine();
			country = read.nextLine();
			//check if referee and competition have the same sport
			typeOfSportReferee = read.nextLine();
			if (!sportType.equals(typeOfSportReferee)) {
				throw new Exception("Some competition has referee that dont referee the same sport");
			}
			//checking type of sport that the referee is doing
			if (sportTypeCorrect(typeOfSportReferee)) {
				//adding the referee into the competition
				setReferee(new Referee(name, country, typeOfSportReferee));
				
				//continue to read Stadium values
				String staidumName,place;
				int numberOfSeats;
				staidumName = read.nextLine();
				place = read.nextLine();
				try {
					numberOfSeats = read.nextInt();
				}
				catch (InputMismatchException e) {
					throw new Exception("Number of seats should be a number!");
				}
				
				//adding the stadium into the competition
				setStadium(new Stadium(staidumName, place, numberOfSeats));
			}
			else {
				throw new Exception("One of the Referee is has worng type of sport to referee");
			}
		}
		else {
			throw new Exception("The file contains worng type of sport");
		}
	}
	

	//Methods
	protected boolean sportTypeCorrect(String sportType) {
		for (int i = 0; i < typeOfSport.length; i++) {
			if (sportType.equals(typeOfSport[i])) {
				return true;
			}
		}
		return false;
	}
	public void changeReferee(String newName, String newCountry, String sportType) {
		referee.setTypeOfSport(sportType);
		referee.setName(newName);
		referee.setCountry(newCountry);
	}
	public void changeStadium(String newName, String newPlace, int newNumOfSeats) {
		stadium.setNewName(newName);
		stadium.setNewPlace(newPlace);
		stadium.setNewNumberOfSeats(newNumOfSeats);
	}


	//Getters and setters
	public String getSportType() {
		return sportType;
	}
	public void setSportType(String typeOfCompetition) {
		this.sportType = typeOfCompetition;
	}
	public Referee getReferee() {
		return referee;
	}
	public void setReferee(Referee referee) {
		this.referee = referee;
	}
	public Stadium getStadium() {
		return stadium;
	}
	public void setStadium(Stadium studium) {
		this.stadium = studium;
	}

	
	//toString
	@Override
	public String toString() {
		return  "Type Of Competition: " + sportType
				+ "\nReferee:\n" + referee
				+ "\nStudium:\n" + stadium +"\n";
	}

	
	//Equals
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Competition other = (Competition) obj;
		if (referee == null) {
			if (other.referee != null)
				return false;
		} else if (!referee.equals(other.referee))
			return false;
		if (stadium == null) {
			if (other.stadium != null)
				return false;
		} else if (!stadium.equals(other.stadium))
			return false;
		if (sportType == null) {
			if (other.sportType != null)
				return false;
		} else if (!sportType.equals(other.sportType))
			return false;
		return true;
	
	
	}
	//copy of the competition
	@Override
	public Competition clone() throws CloneNotSupportedException {
		return (Competition) super.clone();
	}
}

package Model;

import java.util.Vector;

//Generic class for all types of competitions
public class TypeOfCompetition<T extends Competition> {
	//Variables
	private Vector<T> allCompetitions;
	
	
	//Constructor
	public TypeOfCompetition(Vector<T> allCompetitions) {
		this.allCompetitions = allCompetitions;
	}
	public TypeOfCompetition() {
		allCompetitions = new Vector<T>();
	}
	
	
	//Methods
	
	//Adding new specific competition
	public void add(T newCompetition) {
		allCompetitions.add(newCompetition);
	}
	public T getCompetition(int index) {
		return allCompetitions.get(index);
	}
}

package Model;

import java.util.Scanner;

public class Team implements Cloneable {
	//Variables
	private String country;
	
	
	//Constructor
	public Team(String country) {
		this.country = country;
	}
	public Team(Scanner read) {
		setCountry(read.nextLine());
	}

		
	//Getters and setters
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	

	//toString
	@Override
	public String toString() {
		return country;
	}
	
	
	//Equals
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Team other = (Team) obj;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		return true;
	}
	
	
	//copy of the question
	@Override
	public Team clone() throws CloneNotSupportedException {
		return (Team) super.clone();
	}
}

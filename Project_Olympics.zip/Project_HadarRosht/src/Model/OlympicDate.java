package Model;

import java.time.LocalDateTime;

public class OlympicDate {
	//Variables
	protected String startDate;
	protected String endDate;
	
	
	//Constructor
	public OlympicDate() {
		startDate = "";
		endDate = "";
		//Starting the contest
		setContest(true);
	}
	
	
	//Getters and setters
	public String getStartDate() {
		return startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	
	
	//Equals
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OlympicDate other = (OlympicDate) obj;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		return true;
	}


	//toString
	@Override
	public String toString() {
		return  "Start date: "+startDate+ "\n"+
				"End date :"+endDate;
	}

	
	//Methods
	public void setContest(boolean start) {
		LocalDateTime currectDate = LocalDateTime.now();
		if (start) {
			if (currectDate.getMinute()<10) {
				startDate += currectDate.getDayOfMonth()+"/"+currectDate.getMonthValue()+"/"+currectDate.getYear()+" "+currectDate.getHour()+":"+"0"+currectDate.getMinute();
			}
			else {
				startDate += currectDate.getDayOfMonth()+"/"+currectDate.getMonthValue()+"/"+currectDate.getYear()+" "+currectDate.getHour()+":"+currectDate.getMinute();
			}
		}
		else {
			if (currectDate.getMinute()<10) {
				endDate += currectDate.getDayOfMonth()+"/"+currectDate.getMonthValue()+"/"+currectDate.getYear()+" "+currectDate.getHour()+":"+"0"+currectDate.getMinute();
			}
			else {
				endDate += currectDate.getDayOfMonth()+"/"+currectDate.getMonthValue()+"/"+currectDate.getYear()+" "+currectDate.getHour()+":"+currectDate.getMinute();
			}
		}
	}
}

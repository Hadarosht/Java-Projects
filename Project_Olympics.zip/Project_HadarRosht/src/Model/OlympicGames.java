package Model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import Listeners.BIListenable;

//this class will manage all the activities
public class OlympicGames {
	//Variables
	private ArrayList<BIListenable> allListeners;
	
	//the array of all the competitions
	private ArrayList<Competition> competitions;
	//two arrays with different kind of competition (will be easier to manage the system later on).
	private TypeOfCompetition<PersonalCompetition> c1;
	private TypeOfCompetition<TeamCompetition> c2;
	
	private Country[] allCountries;
	private Map<String,Integer> countryParticipants;
	private OlympicDate dateOfContest;
	
	
	//Constructor
	public OlympicGames() throws Exception {
		
		allListeners = new ArrayList<BIListenable>();
		c1 = new TypeOfCompetition<PersonalCompetition>();
		c2 = new TypeOfCompetition<TeamCompetition>();
		countryParticipants = new LinkedHashMap<>();
		
		//starting competitions without info
		competitions = withoutInfo();
		
		//creating array of points for each existed country that participates in the contest
		createListOfPoints();
	}

	
	//Register Listener
	public void registerListener(BIListenable l) {
		allListeners.add(l);
	}

	
	//Getters and setters
	public ArrayList<Competition> getCompetitions() {
		return competitions;
	}
	public void setCompetitions(ArrayList<Competition> competitions) {
		this.competitions = competitions;
	}
	public TypeOfCompetition<PersonalCompetition> getC1() {
		return c1;
	}
	public void setC1(TypeOfCompetition<PersonalCompetition> c1) {
		this.c1 = c1;
	}
	public TypeOfCompetition<TeamCompetition> getC2() {
		return c2;
	}
	public void setC2(TypeOfCompetition<TeamCompetition> c2) {
		this.c2 = c2;
	}


	//toString
	@Override
	public String toString() {
		return "OlympicGames [competitions=" + competitions + ", c1=" + c1 + ", c2=" + c2 + ", countMedals="
				+ Arrays.toString(allCountries) + "]";
	}

	
	//Equals
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OlympicGames other = (OlympicGames) obj;
		if (c1 == null) {
			if (other.c1 != null)
				return false;
		} else if (!c1.equals(other.c1))
			return false;
		if (c2 == null) {
			if (other.c2 != null)
				return false;
		} else if (!c2.equals(other.c2))
			return false;
		if (competitions == null) {
			if (other.competitions != null)
				return false;
		} else if (!competitions.equals(other.competitions))
			return false;
		if (!Arrays.equals(allCountries, other.allCountries))
			return false;
		return true;
	}
	
	
	//Methods
	private void createListOfPoints() {
		countryParticipants.put("Israel", 0);
		countryParticipants.put("USA", 0);
		countryParticipants.put("Russia", 0);
		countryParticipants.put("Spain", 0);
		countryParticipants.put("France", 0);
		countryParticipants.put("Argentina", 0);
		countryParticipants.put("Belgium", 0);
		countryParticipants.put("Brazil", 0);
		countryParticipants.put("China", 0);
		countryParticipants.put("Germany", 0);

	}
	//Starting contest without file
	private ArrayList<Competition> withoutInfo() {
		ArrayList<Competition> competitions = new ArrayList<Competition>();
		//there is 6 types of competitions
		TeamCompetition teamComp1 = new TeamCompetition("Runner");
		TeamCompetition teamComp2 = new TeamCompetition("Jumper");
		TeamCompetition teamComp3 = new TeamCompetition("Runner&Jumper");
		PersonalCompetition peronalComp1 = new PersonalCompetition("Runner");
		PersonalCompetition peronalComp2 = new PersonalCompetition("Jumper");
		PersonalCompetition peronalComp3 = new PersonalCompetition("Runner&Jumper");

		//starting new 3 team competitions. each of them has different type of sport
		competitions.add(teamComp1);
		competitions.add(teamComp2);
		competitions.add(teamComp3);
		c2.add(teamComp1);
		c2.add(teamComp2);
		c2.add(teamComp3);
		
		competitions.add(peronalComp1);
		competitions.add(peronalComp2);
		competitions.add(peronalComp3);
		c1.add(peronalComp1);
		c1.add(peronalComp2);
		c1.add(peronalComp3);

		return competitions;
	}
	//Send to view the data by default by kind of competition
	public void printDataFromFile() {
		try {
			readInfo("D:/Chrome Downloads/Olympic games contest.txt");
		}
		catch (FileNotFoundException e) {
			fireThrowErrorNotification("There has been a problem reading the file");
		}
		catch (Exception e) {
			fireThrowErrorNotification("There has been a problem reading the file");
		}
		fireShowDataByDefaultEvent(c1);
		fireShowDataByDefaultEvent(c2);
		fireThrowNotification("The system read your file successfully!");
	}


	//Read info from file
	private void readInfo(String address) throws Exception {
		//array of reading from file
		ArrayList<Competition> competitionsFile = new ArrayList<Competition>();
		TypeOfCompetition<PersonalCompetition> c1File = new TypeOfCompetition<PersonalCompetition>();
		TypeOfCompetition<TeamCompetition> c2File = new TypeOfCompetition<TeamCompetition>();
		
		
		//search for the file and reads it
		File f = new File(address);
		Scanner read = new Scanner(f);
		int numOfCompetitions = read.nextInt();
		read.nextLine();
		
		//reading each competition from file
		for (int i = 0; i < numOfCompetitions; i++) {
			//getting string to indicates if competition is personal or by teams
			String type = read.nextLine();
			if (type.equals("personal")) {
				competitionsFile.add(new PersonalCompetition(read));
				//adding the exact competition to array of personal competition
				c1File.add((PersonalCompetition) competitionsFile.get(i));//CHECK
			}
			else if (type.equals("team")){
				competitionsFile.add(new TeamCompetition(read));
				//adding the exact competition to array of team competition
				c2File.add((TeamCompetition) competitionsFile.get(i));//CHECK
			}
			else {
				//wrong input of type of competition
				throw new Exception("Wrong type of competition!");
			}
			//line with space
			read.nextLine();
		}
		//Updating the Variables
		competitions = competitionsFile;
		c1 = c1File;
		c2 = c2File;
	}
	public void addAthlete(String country, String name, String sportType) {
		boolean atheleteExist = false;
		//Checking the name
		if (checkingLetters(name)) {
			//Searching for the right competition of sport
			for (int i = 0; i < 3; i++) {
				if (c1.getCompetition(i).getSportType().equals(sportType)) {
					//Check if the athlete is already exist in the competition
					for (int j = 0; j < c1.getCompetition(i).getAttendeesList().size(); j++) {
						if (c1.getCompetition(i).getAttendeesList().get(j).getName().equals(name)) {
							fireThrowErrorNotification("This althere is already exist in this competition!");
							atheleteExist = true;
						}
					}
					if (!atheleteExist) {
						//Adding the athlete
						Athlete a = new Athlete(country, name);
						c1.getCompetition(i).addAthleteToCompetition(a);
						fireAddAthleteToModelEvent(a, c1.getCompetition(i));
						break;
					}
				}
			}
		}
		else {
			fireThrowErrorNotification("Name of the athlete should be with letters");
		}
	}
	public void removeAthlete(String id) {
		//Variables
		int idNum = getNumberFromString(id);
		Athlete a = null;
		int index=0;
		
		//Checking the id in personal competitions
		for (int i = 0; i < 3 && a==null; i++) {
			a = c1.getCompetition(i).removeAthleteFromCompetition(idNum);
			index = i;
		}
		if (a==null) {
			fireThrowErrorNotification("The id is not found");
		}
		else {
			fireRemoveAthleteFromModelEvent(a,c1.getCompetition(index));
		}
	}
	public void addTeam(String country, String sportType) {
		//Searching for the specific competitions by sport type
		for (int i = 0; i < 3; i++) {
			if (c2.getCompetition(i).getSportType().equals(sportType)) {
				//Check if the country that picked by user is already exist in the competition
				if (c2.getCompetition(i).addTeamToCompetition(country)) {
					fireAddTeamToModelEvent(country, sportType, c2.getCompetition(i));
					break;
				}
				else {
					fireThrowErrorNotification("The team is already exist in this competition");
				}
			}
		}
	}
	public void removeTeam(String country, String sportType) {
		//Searching for the specific type of competition by sportType
		for (int i = 0; i < 3; i++) {
			if (c2.getCompetition(i).getSportType().equals(sportType)) {
				//Check if the country that picked by user is exist in this kind of competition
				if (c2.getCompetition(i).removeTeamFromCompetition(country)) {
					//The country has been removed
					fireRemoveTeamFromModelEvent(country, sportType, c2.getCompetition(i));
				}
				else {
					fireThrowErrorNotification("The team is not exist in this competition!");
				}
			}
		}
	}
	public void changeReferee(String competitionType, String sportType, String newName, String newCountry) {
		//check for exceptions
		if (!checkingLetters(newName) || !checkingLetters(newCountry)) {
			//user entered name/country that is not letter or space
			fireThrowErrorNotification("One of the fields has worng input (not letters)");
		}
		else {
			//checking the type of the competition
			if (competitionType.equals("Personal")) {
				//checking which referee need to be changed by the sport type of competition
				for (int i = 0; i < 3; i++) {
					if (c1.getCompetition(i).getSportType().equals(sportType)) {
						//changing the referee
						c1.getCompetition(i).changeReferee(newName, newCountry, sportType);
						fireRefereeHasBeenChanged(newName, competitionType, sportType, c1.getCompetition(i));
					}
				}
			}
			else {
				//checking which referee need to be changed by the sport type of competition
				for (int i = 0; i < 3; i++) {
					if (c2.getCompetition(i).getSportType().equals(sportType)) {
						//changing the referee
						c2.getCompetition(i).changeReferee(newName, newCountry, sportType);
						fireRefereeHasBeenChanged(newName, competitionType, sportType, c2.getCompetition(i));
					}
				}
			}
		}	
	}
	public void changeStadium(String competitionType, String sportType, String newName, String newPlace, String newNumOfSeats) {
		//check for exceptions
		if (!checkingLetters(newName)) {
			fireThrowErrorNotification("Name input is wrong! (must include letters");
		}
		if (!checkingLetters(newPlace)) {
			fireThrowErrorNotification("Place input is wrong! (must include letters");
		}
		int numOfSeats = getNumberFromString(newNumOfSeats);
		if (numOfSeats != 0) {
			if (competitionType.equals("Personal")) {
				//checking which stadium need to be changed by the sport type of competition
				for (int i = 0; i < 3; i++) {
					if (c1.getCompetition(i).getSportType().equals(sportType)) {
						//changing the stadium
						c1.getCompetition(i).changeStadium(newName, newPlace, numOfSeats);
						fireStadiumHasBeenChanged(newName, newPlace, numOfSeats, c1.getCompetition(i));
					}
				}
			}
			else {
				//checking which stadium need to be changed by the sport type of competition
				for (int i = 0; i < 3; i++) {
					if (c2.getCompetition(i).getSportType().equals(sportType)) {
						//changing the stadium
						c2.getCompetition(i).changeStadium(newName, newPlace, numOfSeats);
						fireStadiumHasBeenChanged(newName, newPlace, numOfSeats, c2.getCompetition(i));
					}
				}
			}
		}
	}
	public boolean legalCompetition() {		
		//check if both of personal and team competitions have enough participants
		for (int i = 0; i < competitions.size(); i++) {
			if (competitions.get(i) instanceof PersonalCompetition) {
				//check if personal competitions have enough participants to start the contest
				if (((PersonalCompetition) competitions.get(i)).getAttendeesList().size() < 3) {
					return false;
				}
				//check if personal competitions assigned referee
				if (((PersonalCompetition) competitions.get(i)).getReferee().getName() == null) {
					return false;
				}
				//check if personal competitions assigned stadium
				if (((PersonalCompetition) competitions.get(i)).getStadium().getName() == null) {
					return false;
				}
			}
			else {
				//check if team competitions have enough participants to start the contest
				if (((TeamCompetition) competitions.get(i)).getAttendeesList().size() < 3) {
					return false;
				}
				//check if team competitions assigned referee
				if (((TeamCompetition) competitions.get(i)).getReferee().getName() == null) {
					return false;
				}
				//check if team competitions assigned stadium
				if (((TeamCompetition) competitions.get(i)).getStadium().getName() == null) {
					return false;
				}
			}
		}
		return true;
	}
	public String getStartDate() {
		//Starting the olympic games
		dateOfContest = new OlympicDate();
		//returning the exact date
		return dateOfContest.getStartDate();
	}
	public int[] getAmount() {
		int[] amount = {0, 0, 0};
		for (int i = 0; i < competitions.size(); i++) {
			//getting the information of personal competition
			if (competitions.get(i) instanceof PersonalCompetition) {
				//counting the amount of seats
				amount[2] += ((PersonalCompetition) competitions.get(i)).getStadium().getNumberOfSeats();
				//amount of all the athletes
				amount[0] += ((PersonalCompetition) competitions.get(i)).getAttendeesList().size();
			}
			//getting the information of team competition
			else {
				//counting the amount of seats
				amount[2] += ((TeamCompetition) competitions.get(i)).getStadium().getNumberOfSeats();
				//amount of all the teams
				amount[1] += ((TeamCompetition) competitions.get(i)).getAttendeesList().size();
			}
		}
		return amount;
	}
	public int countryAppearance(String amountCheck) {
		int count=0;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < c1.getCompetition(i).getAttendeesList().size(); j++) {
				//check in the personal competitions
				if (c1.getCompetition(i).getAttendeesList().get(j).getCountry().equals(amountCheck)) {
					//there is a match between pick and existed country
					count++;
				}
			}
			for (int j = 0; j < c2.getCompetition(i).getAttendeesList().size(); j++) {
				//check in the team competitions
				if (c2.getCompetition(i).getAttendeesList().get(j).getCountry().equals(amountCheck)) {
					//there is a match between pick and existed country
					count++;
				}
			}
		}
		return count;
	}
	//Starting the contest and save info into file
	public void showTopThreeAndQuit() {
		//starting the contest - randomly pick three winners of each competition and put them in topThree array
		for (int i = 0; i < competitions.size(); i++) {
			if (competitions.get(i) instanceof PersonalCompetition) {
				((PersonalCompetition) competitions.get(i)).startCompetition();
				//adding medal to specific country if it appears in the top 3 winners
				for (int j = 0; j < 3; j++) {
					int plusPoint = countryParticipants.get(((PersonalCompetition) competitions.get(i)).getTopThree()[j]);
					//adding extra point
					plusPoint++;
					//inserts to the exact map the new amount of points
					countryParticipants.put(((PersonalCompetition) competitions.get(i)).getTopThree()[j], plusPoint);
				}
			}
			else {
				((TeamCompetition) competitions.get(i)).startCompetition();
				//adding medal to specific country if it appears in the top 3 winners
				for (int j = 0; j < 3; j++) {
					int plusPoint = countryParticipants.get(((TeamCompetition) competitions.get(i)).getTopThree()[j]);
					//adding extra point
					plusPoint++;
					//inserts to the exact map the new amount of points
					countryParticipants.put(((TeamCompetition) competitions.get(i)).getTopThree()[j], plusPoint);
				}
			}
		}
		
		//calling a function to sort the map list by its values
		Map<String,Integer> orderMap = sortMap();
		
		//crating array of all the participants countries with their points
		ArrayList<Country> listOfPoints = new ArrayList<Country>();
		for (Map.Entry<String, Integer> e : orderMap.entrySet()) {
			//first index has max points
			listOfPoints.add(new Country(e.getKey(), e.getValue()));
		}
		
		
		//Creating top three message (testing method)
		
		//checking if there is a draw between the top three winners;
		String firstPlace = "1st - " + listOfPoints.get(0).getCountry();
		String secondPlace = "2st - ";
		String thirdPlace = "3st - ";
		int index = 1;
		
		//checking first place
		while (listOfPoints.get(0).getAmountOfPoints() == listOfPoints.get(index).getAmountOfPoints()) {
			firstPlace += ", " + listOfPoints.get(index).getCountry();
			index++;
			if (index>=listOfPoints.size()) {
				break;
			}
		}
		secondPlace += listOfPoints.get(index).getCountry();
		int index2 = index+1;
		//checking second place
		if (index2 < listOfPoints.size()) {
			while (listOfPoints.get(index).getAmountOfPoints() == listOfPoints.get(index2).getAmountOfPoints()) {
				secondPlace += ", " + listOfPoints.get(index2).getCountry();
				index2++;
				if(index2>=listOfPoints.size()) {
					break;
				}
			}
		}
		thirdPlace += listOfPoints.get(index2).getCountry();
		int index3 = index2+1;
		//checking third place
		if (index3 < listOfPoints.size()) {
			while (listOfPoints.get(index2).getAmountOfPoints() == listOfPoints.get(index3).getAmountOfPoints()) {
				thirdPlace += ", " +listOfPoints.get(index3).getCountry();
				index3++;
				if (index3>=listOfPoints.size()) {
					break;
				}
			}
		}
		
		String winnerMsg = "";
		winnerMsg += firstPlace +"\n"
				  +  secondPlace +"\n"
				  +  thirdPlace +"\n";
		
		
		//updating end date of the contest
		dateOfContest.setContest(false);
		
		//save information into file
		try {
			saveInformationIntoFile(orderMap,winnerMsg);
		}
		catch (FileNotFoundException e) {
			fireThrowErrorNotification("There has been a problem to save the info in your file");
		}
		catch (Exception e) {
			fireThrowErrorNotification("There has been a problem to save the info in your file");
		}
		
		//sending the top three winners to views
		fireOlympicGamesHasFinishedMessage(winnerMsg, orderMap);
	}	
	



	//Methods
	private boolean checkingLetters(String name) {
		String[] checkLetters = name.split("");
		//check if the name of the athlete has letters in his name
		for (int i = 0; i < checkLetters.length; i++) {
			if (Character.isLetter(name.charAt(i)) || checkLetters[i].charAt(0) == 32) {
				continue;
			}
			else {
				return false;
			}
		}
		return true;
	}
	private int getNumberFromString(String id) {
		try {
			return Integer.parseInt(id);
		}
		catch (InputMismatchException | NumberFormatException e){
			fireThrowErrorNotification("Input of number of seats should be a number!");
		}
		catch (Exception e) {
			fireThrowErrorNotification("Input of number of seats should be a number!");
		}
		return 0;
	}
	private Map<String,Integer> sortMap() {
		Map<String,Integer> orderMap = new LinkedHashMap<>();
		countryParticipants.entrySet().stream().sorted(Map.Entry.comparingByValue(Collections.reverseOrder())).forEachOrdered(x -> orderMap.put(x.getKey(), x.getValue()));
		
		return orderMap;
	}
	private void saveInformationIntoFile(Map<String,Integer> orderMap, String winnerMsg) throws FileNotFoundException {
		File f = new File("D:/Chrome Downloads/Result of olympic games.txt");
		PrintWriter pw = new PrintWriter(f);
		//Headline
		pw.println("\tThe Olympic Games\n");
		//Date of the olympic games
		pw.println(dateOfContest.toString()+"\n");
		//Announce the winners
		pw.println(winnerMsg);
		//Top three of each competition
		for (int i = 0; i < 3; i++) {
			pw.println(c1.getCompetition(i).getTopThreeText());
			pw.println(c2.getCompetition(i).getTopThreeText());
		}
		//Show the list of points of each country
		pw.println("\nCountry participants list with points included: ");
		for (Map.Entry<String,Integer> e : orderMap.entrySet()) {
			pw.println(e.getKey() +" : "+ e.getValue());
		}
		pw.close();
	}
	


	//Model to View
	private void fireShowDataByDefaultEvent(TypeOfCompetition<?> c) {
		for (BIListenable l : allListeners) {
			l.printInfoFromFile(c);
		}
	}
	private void fireThrowErrorNotification(String msg) {
		for (BIListenable l : allListeners) {
			l.errorNotificationFromEvent(msg);
		}
	}
	private void fireThrowNotification(String msg) {
		for (BIListenable l : allListeners) {
			l.notificationFromEvent(msg);
		}
	}
	private void fireAddAthleteToModelEvent(Athlete a,PersonalCompetition c) {
		for (BIListenable l : allListeners) {
			l.addAthleteToModelEvent(a, c);
		}
	}
	private void fireRemoveAthleteFromModelEvent(Athlete a,PersonalCompetition c) {
		for (BIListenable l : allListeners) {
			l.removeAthleteFromModelEvent(a, c);
		}
	}
	private void fireAddTeamToModelEvent(String country, String sportType, TeamCompetition c) {
		for (BIListenable l : allListeners) {
			l.addTeamToModelEvent(country, sportType, c);
		}
	}
	private void fireRemoveTeamFromModelEvent(String country, String sportType, TeamCompetition c) {
		for (BIListenable l : allListeners) {
			l.removeTeamFromModelEvent(country, sportType, c);
		}
	}
	private void fireRefereeHasBeenChanged(String newName, String competitionType, String sportType, Competition c) {
		for (BIListenable l : allListeners) {
			l.changeRefereeFromModelEvent(newName, competitionType, sportType, c);
		}
	}
	private void fireStadiumHasBeenChanged(String newName, String newPlace, int numOfSeats, Competition c) {
		for (BIListenable l : allListeners) {
			l.changeStadiumFromModelEvent(newName, newPlace, numOfSeats, c);
		}
	}
	private void fireOlympicGamesHasFinishedMessage(String winnerMsg, Map<String,Integer> countryParticipants) {
		for (BIListenable l : allListeners) {
			l.olympicGamesHasFinishedMessage(winnerMsg, countryParticipants);
		}
	}
}

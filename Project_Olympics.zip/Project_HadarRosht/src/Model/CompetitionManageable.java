package Model;

public interface CompetitionManageable {
	void startCompetition();
	String[] getTopThree();
	String getTopThreeText();
}

package Model;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class TeamCompetition extends Competition implements CompetitionManageable {
	
	//Variables
	private ArrayList<Team> attendeesListTeam;
	private String[] topThree;
	
	
	//Constructor
	public TeamCompetition(String sportType) {
		super(sportType);
		attendeesListTeam = new ArrayList<Team>();
		topThree = new String[3];
	}
	
	
	//Reading constructor
	public TeamCompetition(Scanner read) throws Exception {
		super(read);
		attendeesListTeam = new ArrayList<Team>();
		int amount;
		try {
			amount = read.nextInt();
		}
		catch (InputMismatchException e) {
			throw new Exception("The amount number of the teams is worng!");
		}
		read.nextLine();
		for (int i = 0; i < amount; i++) {
			attendeesListTeam.add(new Team(read));
		}
		//creating array of the top three winners
		topThree = new String[3];
	}


	@Override
	public String toString() {
		String text = "";
		text += super.toString();
		if (attendeesListTeam.size() == 0) {
			text += "No Teams assigned yet";
		}
		else {
			for (int i = 0; i < attendeesListTeam.size(); i++) {
				text += attendeesListTeam.get(i).toString() +"\n";
			}
		}
		return text;
	}


	//Getters and setters
	public ArrayList<Team> getAttendeesList() {
		return attendeesListTeam;
	}
	
	
	//Methods
	public boolean addTeamToCompetition(String checkCountry) {
		for (int i = 0; i < attendeesListTeam.size(); i++) {
			if (attendeesListTeam.get(i).getCountry().equals(checkCountry)) {
				//Country user's is already in that competition
				return false;
			}
		}
		attendeesListTeam.add(new Team(checkCountry));
		return true;
	}
	public boolean removeTeamFromCompetition(String countryRemove) {
		//removing the team from the competition
		for (int i = 0; i < attendeesListTeam.size(); i++) {
			if (attendeesListTeam.get(i).getCountry().equals(countryRemove)) {
				//removing the team both from competition and the list of the countries
				attendeesListTeam.remove(i);
				return true;
			}
		}
		//team is not exist in this kind of competition
		return false;
	}
	//pick three random athletes from 
	public void startCompetition() {
		Random rnd = new Random();
		int selected=0;
		//picking randomly 3 athletes winners (first index is 1st place)
		for (int i = 0; i < 3; i++) {
			selected = rnd.nextInt(attendeesListTeam.size());
			topThree[i] = attendeesListTeam.get(selected).getCountry();
			//removing from the array the selected one
			attendeesListTeam.remove(selected);
		
		}
	}
	@Override
	public String[] getTopThree() {
		return topThree;
	}
	@Override
	public String getTopThreeText(){
		return "The winners of team competition in "+getSportType()+ " sport are: \n"+
				"1st - "+topThree[0]+"\n"+
				"2st - "+topThree[1]+"\n"+
				"3st - "+topThree[2];
	}
}

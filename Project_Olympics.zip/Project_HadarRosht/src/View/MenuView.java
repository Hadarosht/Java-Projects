package View;


import java.util.ArrayList;
import java.util.Map;

import javax.swing.JOptionPane;

import Listeners.GUIListenable;
import Model.Athlete;
import Model.Competition;
import Model.PersonalCompetition;
import Model.TeamCompetition;
import Model.TypeOfCompetition;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;

public class MenuView implements ActivitiesViewable{
	//Variables
	private ArrayList<GUIListenable> allListeners;
	
	private Label lblHeader;
	
	
	public MenuView(Stage primaryStage) {
		
		allListeners = new ArrayList<GUIListenable>();
		
		//Stage
		Stage mainStage = new Stage();
		mainStage.setTitle("Menu");
		
		
		//GridPane
		GridPane gpRoot  = new GridPane();
		gpRoot.setPadding(new Insets(40));
		gpRoot.setAlignment(Pos.TOP_LEFT);
		gpRoot.setVgap(30);
		
		//Values for the table 
		lblHeader = new Label("Please choose an option: ");
		//the number of the options is showing as the number of the buttons
		Button[] btnOptions = new Button[8];
		//initialize the buttons 
		for (int i = 0; i < btnOptions.length; i++) {
			btnOptions[i] = new Button((i+1)+"");
		}
		
		//setting them into the grid pane
		gpRoot.add(lblHeader, 0, 0, 2, 1);
		gpRoot.add(btnOptions[0], 0, 1);
		gpRoot.add(btnOptions[1], 0, 2);
		gpRoot.add(btnOptions[2], 0, 3);
		gpRoot.add(btnOptions[3], 0, 4);
		gpRoot.add(btnOptions[4], 0, 5);
		gpRoot.add(btnOptions[5], 0, 6);
		gpRoot.add(btnOptions[6], 0, 7);
		gpRoot.add(btnOptions[7], 0, 8);


		//explanation of each button
		gpRoot.add(new Label(" --- Get data from file (remove previous stored data)"), 1, 1);
		gpRoot.add(new Label(" --- Add athlete to competition"), 1, 2);
		gpRoot.add(new Label(" --- Remove athlete from competition"), 1, 3);
		gpRoot.add(new Label(" --- Add team to competition"), 1, 4);
		gpRoot.add(new Label(" --- Remove team from competition"), 1, 5);
		gpRoot.add(new Label(" --- Change/Add refree details"), 1, 6);
		gpRoot.add(new Label(" --- Change/Add stadium details"), 1, 7);
		gpRoot.add(new Label(" --- Start the contest"), 1, 8);

		
		//User pick a decision
		
		// - Get data from file
		btnOptions[0].setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				//user can read info only one time
				btnOptions[0].setDisable(true);
				
				fireViewAskingForDataFromFile();
			}
		});
		
		// - Add athlete
		btnOptions[1].setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				//Variables
				Stage stg1 = new Stage();
				stg1.setTitle("Adding athlete");
				GridPane option1 = new GridPane();
				option1.setPadding(new Insets(30));
				option1.setVgap(15);
				option1.setHgap(30);
				ComboBox<String> cmbCountry = new ComboBox<String>();
				TextField tfName = new TextField();
				RadioButton rdoRunner = new RadioButton("Runner");
				RadioButton rdoJumper = new RadioButton("Jumper");
				Button btnConfirm = new Button("Confirm");
				Label lblCheckFields = new Label("");
				lblCheckFields.setTextFill(Color.RED);
				
				//Setting variables
				cmbCountry.getItems().addAll("Israel","USA","Russia","Spain","France","Argentina","Belgium","Brazil","China","Germany");
				
				//Variables into grid pane
				option1.add(new Label("Choose county: "), 0, 0);
				option1.add(new Label("Enter name: "), 0, 1);
				option1.add(new Label("Choose sport type: "), 0, 2);
				option1.add(rdoRunner, 0, 3);
				option1.add(rdoJumper, 0, 4);
				option1.add(btnConfirm, 0, 5);
				option1.add(lblCheckFields, 0, 6, 2, 2);
				
				option1.add(cmbCountry, 1, 0);
				option1.add(tfName, 1, 1);
				
				//Setting action
				btnConfirm.setOnAction(new EventHandler<ActionEvent>() {

					@Override
					public void handle(ActionEvent event) {
						//checking fields
						if (cmbCountry.getValue() == null || tfName.getText().trim().isEmpty() || (!rdoJumper.isSelected() && !rdoRunner.isSelected())) {
							lblCheckFields.setText("One of the fields is empty!");
						}
						else {
							//Adding the athlete to a specific kind of competition
							if (rdoJumper.isSelected() && rdoRunner.isSelected()) {
								fireViewAsksToAddAthlete(cmbCountry.getValue(), tfName.getText(), "Runner&Jumper");
								stg1.close();
								
							}
							else if (rdoJumper.isSelected()) {
								fireViewAsksToAddAthlete(cmbCountry.getValue(), tfName.getText(), "Jumper");
								stg1.close();

							}
							else {
								fireViewAsksToAddAthlete(cmbCountry.getValue(), tfName.getText(), "Runner");
								stg1.close();

							}
						}
					}
				});
				stg1.setScene(new Scene(option1,500, 350));
				stg1.show();
			}
		});
		
		// - Remove athlete
		btnOptions[2].setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				//Variables
				Stage stg2 = new Stage();
				stg2.setTitle("Removing athlete");
				GridPane option2 = new GridPane();
				option2.setPadding(new Insets(30));
				option2.setVgap(15);
				option2.setHgap(30);
				TextField tfID = new TextField();
				Button btnConfirm = new Button("Confirm");
				Label lblCheckFields = new Label("");
				lblCheckFields.setTextFill(Color.RED);
				
				//Variables into grid pane
				option2.add(new Label("Enter ID: "), 0, 0);
				option2.add(btnConfirm, 0, 1);
				option2.add(lblCheckFields, 0, 2, 2, 2);
				option2.add(tfID, 1, 0);
				
				btnConfirm.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						//Checking fields
						if (tfID.getText().trim().isEmpty()) {
							lblCheckFields.setText("ID field is empty!");
						}
						else {
							fireViewAskingToRemoveAthlete(tfID.getText());
							stg2.close();
						}
					}
				});
				stg2.setScene(new Scene(option2,380, 200));
				stg2.show();
			}
		});
		
		// - Adding Team
		btnOptions[3].setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				//Variables
				Stage stg3 = new Stage();
				stg3.setTitle("Adding team");
				GridPane option3 = new GridPane();
				option3.setPadding(new Insets(30));
				option3.setVgap(25);
				option3.setHgap(30);
				ComboBox<String> cmbCountry = new ComboBox<String>();
				RadioButton rdoRunner = new RadioButton("Runner");
				RadioButton rdoJumper = new RadioButton("Jumper");
				Button btnConfirm = new Button("Confirm");
				Label lblCheckFields = new Label("");
				lblCheckFields.setTextFill(Color.RED);
				
				//Variables into grid pane
				cmbCountry.getItems().addAll("Israel","USA","Russia","Spain","France","Argentina","Belgium","Brazil","China","Germany");
				option3.add(new Label("Select team: "), 0, 0);
				option3.add(new Label("Sport type: "), 0, 1);
				option3.add(rdoRunner, 0, 2);
				option3.add(rdoJumper, 0, 3);
				option3.add(btnConfirm, 0, 4);
				option3.add(lblCheckFields, 0, 5, 2, 2);
				option3.add(cmbCountry, 1, 0);
				
				btnConfirm.setOnAction(new EventHandler<ActionEvent>() {

					@Override
					public void handle(ActionEvent event) {
						//Checking fields
						if (cmbCountry.getValue() == null || (!rdoJumper.isSelected() && !rdoRunner.isSelected())) {
							lblCheckFields.setText("One of the fields is empty!");
						}
						else {
							//Sending the variables to model
							if (rdoJumper.isSelected() && rdoRunner.isSelected()) {
								fireViewAsksToAddTeam(cmbCountry.getValue(), "Runner&Jumper");
								stg3.close();
							}
							else if (rdoJumper.isSelected()) {
								fireViewAsksToAddTeam(cmbCountry.getValue(), "Jumper");
								stg3.close();

							}
							else {
								fireViewAsksToAddTeam(cmbCountry.getValue(), "Runner");
								stg3.close();
							}
						}
					}

					
				});
				stg3.setScene(new Scene(option3, 500, 350));
				stg3.show();
			}
		});
		
		// - Removing team
		btnOptions[4].setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				//Variables
				Stage stg4 = new Stage();
				stg4.setTitle("Removing team");
				GridPane option4 = new GridPane();
				option4.setPadding(new Insets(30));
				option4.setVgap(25);
				option4.setHgap(30);
				ComboBox<String> cmbCountry = new ComboBox<String>();
				RadioButton rdoRunner = new RadioButton("Runner");
				RadioButton rdoJumper = new RadioButton("Jumper");
				Button btnConfirm = new Button("Confirm");
				Label lblCheckFields = new Label("");
				lblCheckFields.setTextFill(Color.RED);
				
				//Variables into grid pane
				cmbCountry.getItems().addAll("Israel","USA","Russia","Spain","France","Argentina","Belgium","Brazil","China","Germany");
				option4.add(new Label("Select team: "), 0, 0);
				option4.add(new Label("Competition type: "), 0, 1);
				option4.add(rdoRunner, 0, 2);
				option4.add(rdoJumper, 0, 3);
				option4.add(btnConfirm, 0, 4);
				option4.add(lblCheckFields, 0, 5, 2, 2);
				option4.add(cmbCountry, 1, 0);
				
				btnConfirm.setOnAction(new EventHandler<ActionEvent>() {

					@Override
					public void handle(ActionEvent arg0) {
						//Checking fields
						if (cmbCountry.getValue() == null || (!rdoJumper.isSelected() && !rdoRunner.isSelected())) {
							lblCheckFields.setText("One of the fields is empty!");
						}
						else {
							//Sending the variables to model
							if (rdoJumper.isSelected() && rdoRunner.isSelected()) {
								fireViewAsksToRemoveTeam(cmbCountry.getValue(), "Runner&Jumper");
								stg4.close();
							}
							else if (rdoJumper.isSelected()) {
								fireViewAsksToRemoveTeam(cmbCountry.getValue(), "Jumper");
								stg4.close();

							}
							else {
								fireViewAsksToRemoveTeam(cmbCountry.getValue(), "Runner");
								stg4.close();
							}
						}
					}
				});
				stg4.setScene(new Scene(option4, 500, 350));
				stg4.show();
			}
		});
		
		// - Changing referee info
		btnOptions[5].setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				//Variables
				Stage stg5 = new Stage();
				stg5.setTitle("Changing referee");
				GridPane option5 = new GridPane();
				option5.setPadding(new Insets(30));
				option5.setVgap(25);
				option5.setHgap(30);
				ComboBox<String> cmbCompetitionType = new ComboBox<String>();
				RadioButton rdoRunner = new RadioButton("Runner");
				RadioButton rdoJumper = new RadioButton("Jumper");
				TextField tfNewName = new TextField();
				TextField tfNewCountry = new TextField();
				Button btnConfirm = new Button("Confirm");
				Label lblCheckFields = new Label("");
				lblCheckFields.setTextFill(Color.RED);

				cmbCompetitionType.getItems().addAll("Personal", "Team");

				//Variables into grid pane
				option5.add(new Label("Select competition: "), 0, 0);
				option5.add(new Label("Sport type: "), 0, 1);
				option5.add(rdoRunner, 0, 2);
				option5.add(rdoJumper, 0, 3);
				option5.add(new Label("Enter name: "), 0, 4);
				option5.add(new Label("Enter country: "), 0, 5);
				option5.add(btnConfirm, 0, 6);
				option5.add(lblCheckFields, 0, 7, 2, 2);
				option5.add(cmbCompetitionType, 1, 0);
				option5.add(tfNewName, 1, 4);
				option5.add(tfNewCountry, 1, 5);
				
				btnConfirm.setOnAction(new EventHandler<ActionEvent>() {

					@Override
					public void handle(ActionEvent arg0) {
						//Checking fields
						if (cmbCompetitionType.getValue() == null || (!rdoJumper.isSelected() && !rdoRunner.isSelected()) || tfNewCountry.getText().trim().isEmpty() || tfNewName.getText().trim().isEmpty()) {
							lblCheckFields.setText("One of the fields is empty!");
						}
						else {
							//Sending the variables to model
							if (rdoJumper.isSelected() && rdoRunner.isSelected()) {
								fireViewAsksToChangeReferee(cmbCompetitionType.getValue(), "Runner&Jumper", tfNewName.getText(), tfNewCountry.getText());
								stg5.close();
							}
							else if (rdoJumper.isSelected()) {
								fireViewAsksToChangeReferee(cmbCompetitionType.getValue(), "Jumper", tfNewName.getText(), tfNewCountry.getText());
								stg5.close();

							}
							else {
								fireViewAsksToChangeReferee(cmbCompetitionType.getValue(), "Runner", tfNewName.getText(), tfNewCountry.getText());
								stg5.close();
							}
						}
					}
				});
				stg5.setScene(new Scene(option5, 500, 500));
				stg5.show();
			}
		});
		
		// - Change stadium
		btnOptions[6].setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				//Variables
				Stage stg6 = new Stage();
				stg6.setTitle("Changing stadium");
				GridPane option6 = new GridPane();
				option6.setPadding(new Insets(30));
				option6.setVgap(25);
				option6.setHgap(30);
				ComboBox<String> cmbCompetitionType = new ComboBox<String>();
				RadioButton rdoRunner = new RadioButton("Runner");
				RadioButton rdoJumper = new RadioButton("Jumper");
				TextField tfNewName = new TextField();
				TextField tfNewPlace = new TextField();
				TextField tfnewNumOfSears = new TextField();
				Button btnConfirm = new Button("Confirm");
				Label lblCheckFields = new Label("");
				lblCheckFields.setTextFill(Color.RED);
				
				cmbCompetitionType.getItems().addAll("Personal", "Team");
				
				//Variables into grid pane
				option6.add(new Label("Select competition: "), 0, 0);
				option6.add(new Label("Sport type: "), 0, 1);
				option6.add(rdoRunner, 0, 2);
				option6.add(rdoJumper, 0, 3);
				option6.add(new Label("Enter name: "), 0, 4);
				option6.add(new Label("Enter place: "), 0, 5);
				option6.add(new Label("Enter number of seats: "), 0, 6);
				option6.add(btnConfirm, 0, 7);
				option6.add(lblCheckFields, 0, 8, 2, 2);
				option6.add(cmbCompetitionType, 1, 0);
				option6.add(tfNewName, 1, 4);
				option6.add(tfNewPlace, 1, 5);
				option6.add(tfnewNumOfSears, 1, 6);
				
				btnConfirm.setOnAction(new EventHandler<ActionEvent>() {

					@Override
					public void handle(ActionEvent arg0) {
						//Checking fields
						if (cmbCompetitionType.getValue() == null || (!rdoJumper.isSelected() && !rdoRunner.isSelected()) || tfNewPlace.getText().trim().isEmpty() || tfNewName.getText().trim().isEmpty() || tfnewNumOfSears.getText().trim().isEmpty()) {
							lblCheckFields.setText("One of the fields is empty!");
						}
						else {
							//Sending the variables to model
							if (rdoJumper.isSelected() && rdoRunner.isSelected()) {
								fireViewAsksToChangeStadium(cmbCompetitionType.getValue(), "Runner&Jumper", tfNewName.getText(), tfNewPlace.getText(), tfnewNumOfSears.getText());
								stg6.close();
							}
							else if (rdoJumper.isSelected()) {
								fireViewAsksToChangeStadium(cmbCompetitionType.getValue(), "Jumper", tfNewName.getText(), tfNewPlace.getText(), tfnewNumOfSears.getText());
								stg6.close();

							}
							else {
								fireViewAsksToChangeStadium(cmbCompetitionType.getValue(), "Runner", tfNewName.getText(), tfNewPlace.getText(), tfnewNumOfSears.getText());
								stg6.close();
							}
						}
					}					
				});
				stg6.setScene(new Scene(option6, 500, 480));
				stg6.show();
			}
		});
		
		// - Start contest
		btnOptions[7].setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				//Check if there is enough participants (3 at each competition)
				if (!fireAsksForLegalParticipants()) {
					errorNotification("There is not enough participants in the competitions!");
				}
				else {
					//Variables
					Stage stg7 = new Stage();
					stg7.setTitle("Start contest");
					BorderPane bpRoot = new BorderPane();
					bpRoot.setPadding(new Insets(10));
					VBox vbRoot = new VBox();
					GridPane option7 = new GridPane();
					option7.setPadding(new Insets(30));
					option7.setVgap(25);
					option7.setHgap(30);
					
					Label lblHeadLine = new Label("Olympic games began!");
					lblHeadLine.setStyle("-fx-font-weight: bold");
					TextFlow flow = new TextFlow();
					flow.getChildren().add(lblHeadLine);
					flow.setTextAlignment(TextAlignment.CENTER);
					//Getting the start date of olympics
					String startDate = fireViewAsksForStartDate();
					Label lblStartDate = new Label(startDate);
					vbRoot.setAlignment(Pos.TOP_CENTER);
					
					//Variables into vbox
					vbRoot.getChildren().addAll(flow, lblStartDate);
					
					bpRoot.setTop(vbRoot);
					
					//Variables into grid pane
					int[] amount = fireViewAsksForFinalData();
					Label athlets = new Label(amount[0]+"");
					Label teams = new Label(amount[1]+"");
					Label seats = new Label(amount[2]+"");
					athlets.setTextFill(Color.BROWN);
					teams.setTextFill(Color.GOLD);
					seats.setTextFill(Color.GREEN);

					Button btnSpecifcCountry = new Button("Show the number of participants by specific country");
					Button btnResults = new Button("Show the winners and save infromation into file");
					option7.add(new Label("Number of participants in the contest (Athletes): "), 0, 0);
					option7.add(new Label("Number of participants in the contest (Teams): "), 0, 1);
					option7.add(new Label("Number of all seats: "), 0, 2);
					option7.add(btnSpecifcCountry, 0, 3, 2, 1);
					option7.add(btnResults, 0, 4, 2, 1);
					option7.add(athlets, 1, 0);
					option7.add(teams, 1, 1);
					option7.add(seats, 1, 2);

					bpRoot.setCenter(option7);
					
					// - Search for a specific country that participants in the contest
					btnSpecifcCountry.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							Stage stgOption1 = new Stage();
							stgOption1.setTitle("Amount of country participants");
							GridPane optionAmount = new GridPane();
							optionAmount.setPadding(new Insets(30));
							optionAmount.setVgap(25);
							optionAmount.setHgap(30);
							
							//Variables
							Button btnConfirm = new Button("Confirm");
							ComboBox<String> cmbCountries = new ComboBox<String>();
							cmbCountries.getItems().addAll("Israel","USA","Russia","Spain","France","Argentina","Belgium","Brazil","China","Germany");
							Label lblResult = new Label("");
							
							//Variables into grid pane
							optionAmount.add(new Label("Select country"), 0, 0);
							optionAmount.add(btnConfirm, 0, 1);
							optionAmount.add(lblResult, 0, 2, 2, 2);
							optionAmount.add(cmbCountries, 1, 0);
							
							cmbCountries.setOnMouseClicked(new EventHandler<Event>() {
								@Override
								public void handle(Event event) {
									lblResult.setText("");
								}
							});
							
							btnConfirm.setOnAction(new EventHandler<ActionEvent>() {

								@Override
								public void handle(ActionEvent event) {
									lblResult.setText("");
									//Checking fields
									if (cmbCountries.getValue() == null) {
										lblResult.setTextFill(Color.RED);
										lblResult.setText("No input!");
									}
									else {
										//Get the number of country appearance
										int check = fireViewAsksForAmountOfCountry(cmbCountries.getValue());
										//Country did not participants in the contest
										if (check == 0) {
											lblResult.setTextFill(Color.RED);
											lblResult.setText("The Country is not exist in the contest!");
										}
										else {
											lblResult.setTextFill(Color.BLUE);
											lblResult.setText("The Country is appeared "+check+ " times in the contest");
										}
									}
								}
							});
						stgOption1.setScene(new Scene(optionAmount, 450, 220));
						stgOption1.show();
						}
					});
					
					// - Show top three and quit
					btnResults.setOnAction(new EventHandler<ActionEvent>() {

						@Override
						public void handle(ActionEvent arg0) {
							fireViewAsksToShowTopThreeAndQuit();
							stg7.close();
						}

						
					});
					//Closing the menu windows - user can not edit the contest anymore
					mainStage.close();
					stg7.setScene(new Scene(bpRoot, 500, 400));
					stg7.show();
				}
			}

				
		});
		
	
		//initialize stage
		mainStage.setScene(new Scene(gpRoot, 500, 600));
		mainStage.show();
	}

	
	//Menu to Model
	private void fireViewAskingForDataFromFile() {
		for (GUIListenable l : allListeners) {
			l.viewAsksForDataFromFile();
		}
	}
	private void fireViewAsksToAddAthlete(String country, String name, String sportType) {
		for (GUIListenable l : allListeners) {
			l.viewAskingToAddAthlete(country, name, sportType);
		}
	}
	private void fireViewAskingToRemoveAthlete(String id) {
		for (GUIListenable l : allListeners) {
			l.viewAskingToRemoveAthlete(id);
		}
	}
	private void fireViewAsksToAddTeam(String country, String sportType) {
		for (GUIListenable l : allListeners) {
			l.viewAskingToAddTeam(country, sportType);
		}
	}
	private void fireViewAsksToRemoveTeam(String country, String competitionType) {
		for (GUIListenable l : allListeners) {
			l.viewAskingToRemoveTeam(country, competitionType);
		}
	}
	private void fireViewAsksToChangeReferee(String competitionType, String sportType, String newName, String newCountry) {
		for (GUIListenable l : allListeners) {
			l.viewAskingToChangeReferee(competitionType, sportType, newName, newCountry);
		}
	}
	private void fireViewAsksToChangeStadium(String competitionType, String sportType, String newName, String newPlace, String newNumOfSeats) {
		for (GUIListenable l : allListeners) {
			l.viewAskingToChangeStadium(competitionType, sportType, newName, newPlace, newNumOfSeats);
		}
	}
	private String fireViewAsksForStartDate() {
		for (GUIListenable l : allListeners) {
			return l.viewAskingForStartDate();
		}
		return null;
	}
	private int[] fireViewAsksForFinalData() {
		for (GUIListenable l : allListeners) {
			return l.viewAskingForFinalData();
		}
		return null;
	}
	private int fireViewAsksForAmountOfCountry(String amountCheck) {
		for (GUIListenable l : allListeners) {
			return l.viewAskingForAmountOfCountry(amountCheck);
		}
		return 0;
	}
	private boolean fireAsksForLegalParticipants() {
		for (GUIListenable l : allListeners) {
			return l.viewCheckingParticipants();
		}
		return false;
	}
	private void fireViewAsksToShowTopThreeAndQuit() {
		for (GUIListenable l : allListeners) {
			l.viewAskingForTopThreeAndQuit();
		}
	}
	
	
	//Model to Menu
	@Override
	public void registerListener(GUIListenable l) {
		allListeners.add(l);
	}
	@Override
	public void printData(TypeOfCompetition<?> c) {}
	@Override
	public void notificationToView(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Notification", 1);
	}
	@Override
	public void errorNotification(String msg) {
		JOptionPane.showMessageDialog(null, msg, "ERROR", 2);
	}
	@Override
	public void addAthlete(Athlete a, PersonalCompetition c) {
		JOptionPane.showMessageDialog(null, "The athlete: \n"+a.toString()+"\nhas been added!");
	}
	@Override
	public void removeAthlete(Athlete a, PersonalCompetition c) {
		JOptionPane.showMessageDialog(null, "The athlete: \n"+a.toString()+"\nhas been removed!");
	}
	@Override
	public void addTeam(String country, String sportType, TeamCompetition c) {
		JOptionPane.showMessageDialog(null, "The team: \n" + country + " has been added!");
	}
	@Override
	public void removeTeam(String country, String sportType, TeamCompetition c) {
		JOptionPane.showMessageDialog(null, "The team: \n" + country + " has been removed!");
	}
	@Override
	public void refereeChanged(String newName, String competitionType, String sportType, Competition c) {
		JOptionPane.showMessageDialog(null, "Referee has been changed to " + newName);
	}
	@Override
	public void stadiumChanged(String newName, String newPlace, int numOfSeats, Competition c) {
		JOptionPane.showMessageDialog(null, "Stadium has been changed to " + newName);

	}
	@Override
	public void endMessage(String winnersMsg, Map<String,Integer> countryParticipants) {
		JOptionPane.showMessageDialog(null, winnersMsg);
	}
}

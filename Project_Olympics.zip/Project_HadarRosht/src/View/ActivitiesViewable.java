package View;

import java.util.Map;

import Listeners.GUIListenable;
import Model.Athlete;
import Model.Competition;
import Model.PersonalCompetition;
import Model.TeamCompetition;
import Model.TypeOfCompetition;

public interface ActivitiesViewable {
	void registerListener(GUIListenable l);
	void printData(TypeOfCompetition<?> c);
	void addAthlete(Athlete a, PersonalCompetition c);
	void removeAthlete(Athlete a, PersonalCompetition c);
	void addTeam(String country, String sportType, TeamCompetition c);
	void removeTeam(String country, String sportType, TeamCompetition c);
	void notificationToView(String msg);
	void errorNotification(String msg);
	void refereeChanged(String newName, String competitionType, String sportType, Competition c);
	void stadiumChanged(String newName, String newPlace, int numOfSeats, Competition c);
	void endMessage(String winnersMsg, Map<String,Integer> countryParticipants);
	
}

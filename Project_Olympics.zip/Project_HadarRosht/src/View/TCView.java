package View;

import java.util.ArrayList;
import java.util.Map;

import Listeners.GUIListenable;
import Model.Athlete;
import Model.Competition;
import Model.PersonalCompetition;
import Model.TeamCompetition;
import Model.TypeOfCompetition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;

//Team Competition View = TCView
public class TCView implements ActivitiesViewable{
	//Variables
	private ArrayList<GUIListenable> allListeners;
	
	//Labels
	private Label lblRunTypeText;
	private Label lblJumpTypeText;
	private Label lblBothTypeText;
	private Label lblActivities;
	private Label lblMissingMsgForRunners;
	private Label lblMissingMsgForJumpers;
	private Label lblMissingMsgForRunnersAndJumpers;
	
	//Constructor
	public TCView(Stage primaryStage) {
		//Starters
		allListeners = new ArrayList<GUIListenable>();
		lblRunTypeText = new Label("Type of competition: Runners"
				+ "\nReferee:"
				+ "\nNo referee assigned yet"
				+ "\nStadium:"
				+ "\nNo stadium assigned yet"
				+ "\nNo Teams assigned yet");
		lblJumpTypeText = new Label("Type of competition: Jumpers"
				+ "\nReferee:"
				+ "\nNo referee assigned yet"
				+ "\nStadium:"
				+ "\nNo stadium assigned yet"
				+ "\nNo Teams assigned yet");
		lblBothTypeText = new Label("Type of competition: Runners&Jumpers"
				+ "\nReferee:"
				+ "\nNo referee assigned yet"
				+ "\nStadium:"
				+ "\nNo stadium assigned yet"
				+ "\nNo Teams assigned yet");
		lblActivities = new Label("");
		lblMissingMsgForRunners = new Label("Your competition is not fully ready!");
		lblMissingMsgForJumpers = new Label("Your competition is not fully ready!");
		lblMissingMsgForRunnersAndJumpers = new Label("Your competition is not fully ready!");
		lblMissingMsgForRunners.setTextFill(Color.RED);
		lblMissingMsgForJumpers.setTextFill(Color.RED);
		lblMissingMsgForRunnersAndJumpers.setTextFill(Color.RED);
		
		//Setting border pane
		BorderPane bpRoot = new BorderPane();
		bpRoot.setPadding(new Insets(10));
		Label lblHeadLine = new Label("Team Competition");
		lblHeadLine.setStyle("-fx-font-weight: bold");
		TextFlow flow = new TextFlow();
		flow.getChildren().add(lblHeadLine);
		flow.setTextAlignment(TextAlignment.CENTER);
		bpRoot.setTop(flow);
		
		
		//Setting gridPane
		GridPane gpRoot  = new GridPane();
		gpRoot.setPadding(new Insets(10));
		gpRoot.setAlignment(Pos.TOP_LEFT);
		gpRoot.setGridLinesVisible(true);

		gpRoot.setHgap(50);
		
		//Insert values into the table
		Label lblRunAndJump = new Label("Run&Jump");
		Label lblRunner = new Label("Runners");
		Label lblJumper = new Label("Jumper");
		lblRunAndJump.setTextFill(Color.BLUE);
		lblRunner.setTextFill(Color.BLUE);
		lblJumper.setTextFill(Color.BLUE);
		
		FlowPane fpBoth = new FlowPane();
		fpBoth.setAlignment(Pos.TOP_LEFT);
		fpBoth.getChildren().add(lblBothTypeText);
		
		FlowPane fpRun = new FlowPane();
		fpRun.setAlignment(Pos.TOP_LEFT);
		fpRun.getChildren().add(lblRunTypeText);
		
		FlowPane fpJump = new FlowPane();
		fpJump.setAlignment(Pos.TOP_LEFT);
		fpJump.getChildren().add(lblJumpTypeText);
		
		
		gpRoot.add(lblRunAndJump, 0, 0);
		gpRoot.add(lblRunner, 1, 0);
		gpRoot.add(lblJumper, 2, 0);
		gpRoot.add(fpBoth, 0, 1);
		gpRoot.add(fpRun, 1, 1);
		gpRoot.add(fpJump, 2, 1);
		gpRoot.add(lblMissingMsgForRunnersAndJumpers, 0, 2);
		gpRoot.add(lblMissingMsgForRunners, 1, 2);
		gpRoot.add(lblMissingMsgForJumpers, 2, 2);
		
		ScrollPane scroll = new ScrollPane();
		scroll.fitToHeightProperty().set(true);
		scroll.fitToWidthProperty().set(true);
		scroll.setContent(bpRoot);
		gpRoot.setAlignment(Pos.TOP_CENTER);
		
		bpRoot.setCenter(gpRoot);
		bpRoot.setBottom(lblActivities);
		
		
		//Setting stage
		Scene scene = new Scene(scroll, 1300, 450);
		primaryStage.setTitle("Team Competitions");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	

	//Methods
	@Override
	public void registerListener(GUIListenable l) {
		allListeners.add(l);
	}
	private void addMessageRunners(String msg, Label lbl, boolean missingValues) {
		if (missingValues) {
			lblMissingMsgForRunners.setTextFill(Color.RED);
			lblMissingMsgForRunners.setText("Your competition is not fully ready!");
			lbl.setText(msg);
		}
		else {
			lblMissingMsgForRunners.setTextFill(Color.GREEN);
			lblMissingMsgForRunners.setText("Ready to start");
			lbl.setText(msg);
		}
	}
	private void addMessageJumpers(String msg, Label lbl, boolean missingValues) {
		if (missingValues) {
			lblMissingMsgForJumpers.setTextFill(Color.RED);
			lblMissingMsgForJumpers.setText("Your competition is not fully ready!");
			lbl.setText(msg);
		}
		else {
			lblMissingMsgForJumpers.setTextFill(Color.GREEN);
			lblMissingMsgForJumpers.setText("Ready to start");
			lbl.setText(msg);
		}
	}
	private void addMessageRunnersJumpers(String msg, Label lbl, boolean missingValues) {
		if (missingValues) {
			lblMissingMsgForRunnersAndJumpers.setTextFill(Color.RED);
			lblMissingMsgForRunnersAndJumpers.setText("Your competition is not fully ready!");
			lbl.setText(msg);
		}
		else {
			lblMissingMsgForRunnersAndJumpers.setTextFill(Color.GREEN);
			lblMissingMsgForRunnersAndJumpers.setText("Ready to start");
			lbl.setText(msg);
		}
	}
	
	
	//Model to View
	@Override
	public void printData(TypeOfCompetition<?> c) {
		if (c.getCompetition(0) instanceof TeamCompetition) {
			//Runner view
			//Check if the competition has referee or stadium or enough teams
			if (c.getCompetition(0).getReferee().getName()==null || c.getCompetition(0).getStadium().getName()==null || ((TeamCompetition) c.getCompetition(0)).getAttendeesList().size()<3) {
				addMessageRunners(c.getCompetition(0).toString(), lblRunTypeText, true);
			}
			else {
				addMessageRunners(c.getCompetition(0).toString(), lblRunTypeText, false);
			}
			//Jumper view
			if (c.getCompetition(1).getReferee().getName()==null || c.getCompetition(1).getStadium().getName()==null || ((TeamCompetition) c.getCompetition(1)).getAttendeesList().size()<3) {
				addMessageJumpers(c.getCompetition(1).toString(), lblJumpTypeText, true);
			}
			else {
				addMessageJumpers(c.getCompetition(1).toString(), lblJumpTypeText, false);

			}
			//Runner&Jumper view
			if (c.getCompetition(2).getReferee().getName()==null || c.getCompetition(2).getStadium().getName()==null || ((TeamCompetition) c.getCompetition(2)).getAttendeesList().size()<3) {
				addMessageRunnersJumpers(c.getCompetition(2).toString(), lblBothTypeText, true);
			}
			else {
				addMessageRunnersJumpers(c.getCompetition(2).toString(), lblBothTypeText, false);
			}
		}
	}
	private void printUpdatedData(TeamCompetition c) {
		if (c.getReferee().getName()==null || c.getStadium().getName()==null || c.getAttendeesList().size()<3) {
			if (c.getSportType().equals("Runner")) {
				addMessageRunners(c.toString(), lblRunTypeText, true);
			}
			if (c.getSportType().equals("Jumper")) {
				addMessageJumpers(c.toString(), lblJumpTypeText, true);
			}
			if (c.getSportType().equals("Runner&Jumper")) {
				addMessageRunnersJumpers(c.toString(), lblBothTypeText, true);
			}
		}
		else {
			if (c.getSportType().equals("Runner")) {
				addMessageRunners(c.toString(), lblRunTypeText, false);
			}
			if (c.getSportType().equals("Jumper")) {
				addMessageJumpers(c.toString(), lblJumpTypeText, false);
			}
			if (c.getSportType().equals("Runner&Jumper")) {
				addMessageRunnersJumpers(c.toString(), lblBothTypeText, false);
			}
		}
	}
	@Override
	public void notificationToView(String msg) {}
	@Override
	public void errorNotification(String msg) {}
	@Override
	public void addAthlete(Athlete a, PersonalCompetition c) {}
	@Override
	public void removeAthlete(Athlete a, PersonalCompetition c) {}
	@Override
	public void addTeam(String country, String sportType, TeamCompetition c) {
		//Updating the text
		printUpdatedData(c);
		lblActivities.setTextFill(Color.BLUE);
		lblActivities.setText("The team " +country+ " has been added to the "+ sportType +" table!");
	}
	@Override
	public void removeTeam(String country, String sportType, TeamCompetition c) {
		printUpdatedData(c);
		lblActivities.setTextFill(Color.RED);
		lblActivities.setText("The " +country+ " team has been removed from the "+ sportType +" table!");
	}
	@Override
	public void refereeChanged(String newName, String competitionType, String sportType, Competition c) {
		if (competitionType.equals("Team")) {
			printUpdatedData((TeamCompetition) c);
			lblActivities.setTextFill(Color.BLUE);
			lblActivities.setText("The competition " +sportType+ " has changed referee to " +newName);
		}
	}
	@Override
	public void stadiumChanged(String newName, String newPlace, int numOfSeats, Competition c) {
		if (c instanceof TeamCompetition) {
			printUpdatedData((TeamCompetition)c);
			lblActivities.setTextFill(Color.BLUE);
			lblActivities.setText("The competition " +c.getSportType()+ " has changed stadium to " + c.getStadium().toString());
		}
	}
	@Override
	public void endMessage(String winnersMsg, Map<String,Integer> countryParticipants) {
		lblActivities.setTextFill(Color.GREEN);
		lblActivities.setText("The contest in finished, showing the participants country divided by their points: \n"
							 + countryParticipants);
	}	
}

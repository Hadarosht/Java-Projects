package Listeners;

public interface GUIListenable {
	void viewAsksForDataFromFile();
	void viewAskingToAddAthlete(String country, String name, String sportType);
	void viewAskingToRemoveAthlete(String id);
	void viewAskingToAddTeam(String country, String sportType);
	void viewAskingToRemoveTeam(String country, String competitionType);
	void viewAskingToChangeReferee(String competitionType, String sportType, String newName, String newCountry);
	void viewAskingToChangeStadium(String competitionType, String sportType, String newName, String newPlace,String newNumOfSeats);
	boolean viewCheckingParticipants();
	String viewAskingForStartDate();
	int[] viewAskingForFinalData();
	int viewAskingForAmountOfCountry(String amountCheck);
	void viewAskingForTopThreeAndQuit();
}

package Listeners;

import java.util.Map;

import Model.Athlete;
import Model.Competition;
import Model.PersonalCompetition;
import Model.TeamCompetition;
import Model.TypeOfCompetition;

public interface BIListenable {
	void printInfoFromFile(TypeOfCompetition<?> c);
	void errorNotificationFromEvent(String msg);
	void notificationFromEvent(String msg);
	void addAthleteToModelEvent(Athlete a, PersonalCompetition c);
	void removeAthleteFromModelEvent(Athlete a,PersonalCompetition c);
	void addTeamToModelEvent(String country, String sportType, TeamCompetition c);
	void removeTeamFromModelEvent(String country, String sportType, TeamCompetition c);
	void changeRefereeFromModelEvent(String newName, String competitionType, String sportType, Competition c);
	void changeStadiumFromModelEvent(String newName, String newPlace, int numOfSeats, Competition c);
	void olympicGamesHasFinishedMessage(String winnersMsg ,Map<String,Integer> countryParticipants);
}
